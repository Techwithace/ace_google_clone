package com.example.ace_google_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
